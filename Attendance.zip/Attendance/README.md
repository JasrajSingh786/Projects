# Attendance

Problem Statement :
In a class room the instructor usually takes attendance each session.
Taking attendance requires about 3 to 10 minutes depending on the size of the class room, not to mention the chaos that usually happens in the meantime.
This is where Shusseki (Japanese for present) comes into play.
Shusseki is a QR code Attendance system that enables students to check themselves into the class as attended.
This is done via the use of QR Codes generated using the course ID, section and current date.
In a perfect environment all students will arrive on time to class but as we all know this doesn’t happen, that is why we decided to implement a feature that lets the instructor edit the status of the student manually while preserving the feature of being able to view his picture in the logs.


This Android app was created for a project at university . Its a QR Code attendance system linked to Firebase 
Teacher would create a course and upload an excel file containing the id then the name of students enrolled .
teacher then generates qr code and shows it, screen mirror it ,project it to a screen .
then students would simply scan the code to be added to the database as present .
teache then can edit the status of the students and view their profile pictures .
